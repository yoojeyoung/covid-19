# @babel/plugin-transform-object-super

> Compile ES2015 object super to ES5

See our website [@babel/plugin-transform-object-super](https://babeljs.io/docs/en/babel-plugin-transform-object-super) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-object-super
```

or using yarn:

```sh
yarn add @babel/plugin-transform-object-super --dev
```
